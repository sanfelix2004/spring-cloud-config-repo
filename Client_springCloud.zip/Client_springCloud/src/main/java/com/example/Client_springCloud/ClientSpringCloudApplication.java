package com.example.Client_springCloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientSpringCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientSpringCloudApplication.class, args);
	}

}
