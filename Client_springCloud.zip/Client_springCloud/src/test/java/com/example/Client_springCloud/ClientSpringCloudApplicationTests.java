package com.example.Client_springCloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientSpringCloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
