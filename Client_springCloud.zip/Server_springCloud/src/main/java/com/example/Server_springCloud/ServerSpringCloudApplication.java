package com.example.Server_springCloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class ServerSpringCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerSpringCloudApplication.class, args);
	}

}
